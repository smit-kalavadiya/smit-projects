export class Report {

    public id?: number;
    public submittedTo?: string;
    public name?: string;
    public phone?: string;
    public email?: string;    
    public date?: Date;
    public message?: string;
  
}
