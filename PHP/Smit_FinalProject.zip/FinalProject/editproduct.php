<!DOCTYPE html>
<html lang="en">

<head>
  <?php
  include("include/connection.php");
  include("operation.php");
  $pid = $_GET['pid'];
  $result = prepare::getProductById($conn, $pid);
  ?>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body style="width:80%; margin-left:auto; margin-right:auto">
  <h1>Edit Product</h1>
  <div>
    <form action="#" method="POST" enctype="multipart/form-data">
      <label for="pname">Product ID</label>
      <input disabled type="text" value="<?php echo $pid; ?>" id="pid" name="pid">
      <label for="pname">Product Name</label>
      <input type="text" id="pname" name="pname" value="<?php echo $result['name']; ?>" placeholder="Product name">
      <label for="price">Price</label>
      <input type="text" id="price" value="<?php echo $result['price']; ?>" name="price" placeholder="Price">
      <label for="description">Description</label>
      <input type="text" id="description" value="<?php echo $result['description']; ?>" name="description" placeholder="Description">
      <label>Product Image</label></br></br>
      <img style="background-color:white; border-radius:8px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); width:20%; height:20%" src="uploads/<?php echo $result['image']; ?>" /></br></br>
      Edit Product Image:
      <input type="file" name="uploadedFile" id="fileToUpload">
      <input type="submit" name="submit" value="SUBMIT" />
    </form>
  </div>
</body>

</html>

<?php


if (isset($_POST['submit'])) {

  $pname = $_POST['pname'];
  $pprice = $_POST['price'];
  $pdesc = $_POST['description'];

  if (!isset($_FILES['uploadedFile']) || $_FILES['uploadedFile']['error'] == UPLOAD_ERR_NO_FILE) {

    $pimage = $result['image'];

    if (prepare::updateProductById($conn, $pid, $pname, $pimage, $pprice, $pdesc)) {
      header("Refresh:0");
    }
  } else {
    $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
    $pimage = $_FILES['uploadedFile']['name'];
    $fileSize = $_FILES['uploadedFile']['size'];
    $fileType = $_FILES['uploadedFile']['type'];
    $fileNameCmps = explode(".", $pimage);
    $fileExtension = strtolower(end($fileNameCmps));

    $uploadFileDir = './uploads/';
    $dest_path = $uploadFileDir . $pimage;


    // filter for image upload
    if ($fileType != "image/jpeg" && $fileType != "image/png" && $fileType != "image/jpeg") {

      echo "Sorry, only JPG, PNG, and JPEG files are allowed.";
    } else {
      if ($fileSize > 2048000) {

        echo "Sorry, Image is larger than 2 MB";
      } else {
        if (file_exists($dest_path)) {
          echo "Sorry, file already exists.";
        } else {
          move_uploaded_file($fileTmpPath, $dest_path);
          prepare::updateProductById($conn, $pid, $pname, $pimage, $pprice, $pdesc);
          header("Refresh:0");
          echo "Data Updated";
        }
      }
    }
  }
}



?>