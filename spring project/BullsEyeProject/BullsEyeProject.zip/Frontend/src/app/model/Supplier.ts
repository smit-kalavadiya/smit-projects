export class Supplier {
    public id?: number;
    public address?: string;
    public email?: string;
    public name?: string;
    public phone?: number;
    public profileUrl?: string;
}
