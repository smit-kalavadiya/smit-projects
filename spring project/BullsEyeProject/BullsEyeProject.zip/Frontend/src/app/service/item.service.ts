import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Item } from '../model/Item';


@Injectable({
  providedIn: 'root'
})
export class ItemService {
  

  constructor(private http: HttpClient) { 

  }

  addNewItem(item: Item[]): Observable<string>{
    console.log(item[0].orderid);
    return this.http.post<string>("http://localhost:8080/OrderItems",item);
  }


  getItems(orderid: string): Observable<Item[]>{
    return this.http.post<Item[]>("http://localhost:8080/getItems",orderid);
  }
  

}
