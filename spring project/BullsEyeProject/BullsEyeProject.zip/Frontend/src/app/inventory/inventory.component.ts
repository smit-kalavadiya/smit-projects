import { Component, OnInit } from '@angular/core';
import { Products } from '../model/Products';
import { ProductsService } from '../service/products.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  images: String[] = [];
  products: Products[] = [];
  productId: number = 0;
  constructor(private service: ProductsService, private router:Router) { }

  ngOnInit(): void {
    this.getAllProducts();
    sessionStorage.removeItem("productId");
  }
  getAllProducts() {
    this.service.getProducts().subscribe(data => {
      data.forEach(e => {
        this.products.push(e);
      })
    })
  }

  edit(id: any) {
    sessionStorage.setItem('productId', JSON.stringify(id));
  }
  deleteProduct(id:any){
    this.service.deleteProduct(id).subscribe(data=>{
    })
  }
  getDeleteId(id:any){
    Swal.fire({
      title: 'Sure you want to delete?',
      heightAuto: true,
      showDenyButton: true,
      width: "30%",
      text:"center",
      background: "#fff",
      html: "This product will be deleted",
      confirmButtonText: 'Yes',
      denyButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteProduct(id);
        console.log("Product Deleted");
        Swal.fire('Saved!', '', 'success');
        this.router.navigate(['/']);
      } else if (result.isDenied) {
        Swal.fire('Product not deleted')
      }
    })
  }
}


