import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Item } from '../model/Item';
import { Order } from '../model/Order';
import { ItemService } from '../service/item.service';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  constructor(private service: OrderService, private itemService: ItemService, private router: Router) { }
  orderItem: Item = new Item();
  subtotal: number = 0;
  shipping: number = 0;
  total: number = 0;
  tax: number = 0;

  OrderItems: Item[] = [];
  order: Order = new Order();
  ngOnInit(): void {
    this.order = JSON.parse(sessionStorage.getItem("orderId") || '{}') as Order;    
  }

  onClickSubmit(data: any) {
    this.orderItem = new Item();

    this.orderItem.orderid = this.order.id;
    this.orderItem.name = data.name;
    this.orderItem.quantity = data.quantity;
    this.orderItem.description = data.description;
    this.orderItem.season = data.season;
    this.orderItem.price = data.price;
    this.orderItem.weight = data.weight;
    this.orderItem.dimension = data.dimension;

    this.subtotal += data.quantity * data.price;
    
    this.shipping =this.subtotal*0.10;
    this.tax=this.subtotal*0.15;
    this.total=this.subtotal+this.shipping+this.tax;
    
    // this.orderItem = this.subtotal;
    // this.orderItem = this.shipping;
    // this.orderItem = this.tax;
    // this.orderItem = this.total;

    this.OrderItems.push(this.orderItem);
    console.log(this.OrderItems)
    data.name = "";
    data.quantity = "";
    data.description = "";
    data.season = "";
    data.price = "";
    data.weight = "";
    data.dimension = "";
  }

  call(){
    this.itemService.addNewItem(this.OrderItems).subscribe(data=>{
      console.log("Items added");
    })
  }
  clear(data:any){
    data.name = "";
    data.quantity = "";
    data.description = "";
    data.season = "";
    data.price = "";
    data.weight = "";
    data.dimension = "";
  }

}
