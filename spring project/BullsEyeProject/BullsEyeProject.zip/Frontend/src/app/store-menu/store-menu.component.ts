import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Order } from '../model/Order';
import { EmployeeService } from '../service/employee.service';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-store-menu',
  templateUrl: './store-menu.component.html',
  styleUrls: ['./store-menu.component.css']
})
export class StoreMenuComponent implements OnInit {
  err:string = "";
  order: Order = new Order();
  emp: Employee = new Employee();
  constructor(private service: EmployeeService,private orderservice: OrderService, private router: Router) { }

  ngOnInit(): void {
    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;

    if (Object.keys(this.emp).length == 0) {
      this.router.navigate(['/login-page']);
    }

  }
  onClickSubmit(data: any) {

    this.order.type = data.type;
    if(this.order.date == null){
      this.order.date = new Date();
    }else{
      this.order.date = data.date;
    }
    this.order.status = "In progress";
    this.order.address = data.address;
    this.order.title=data.title;
    this.order.orderby = this.emp.role;
    //console.log(this.order.title);
    if(this.order.type != null && this.order.type != "" && this.order.date != null && this.order.address != null  && this.order.address != ""){
      this.orderservice.addOrder(this.order).subscribe((data: Order) => {  
        sessionStorage.setItem('orderId', JSON.stringify(data));    
        this.router.navigate(['/createOrder']);
      });
    }else{
      this.err = "Please enter all the fields";
    }
    
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/login-page']);
  }

}
