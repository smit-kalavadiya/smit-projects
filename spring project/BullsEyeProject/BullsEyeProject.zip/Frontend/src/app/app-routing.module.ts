import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddItemComponent } from './add-item/add-item.component';
import { CheckReportComponent } from './check-report/check-report.component';
import { DeliveryMenuComponent } from './delivery-menu/delivery-menu.component';
import { EditInventoryComponent } from './edit-inventory/edit-inventory.component';
import { EmployeeComponent } from './employee/employee.component';
import { InventoryComponent } from './inventory/inventory.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { OrdersComponent } from './orders/orders.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { RegionalMenuComponent } from './regional-menu/regional-menu.component';
import { ReportComponent } from './report/report.component';
import { StoreMenuComponent } from './store-menu/store-menu.component';
import { SupplierComponent } from './supplier/supplier.component';
import { WarehouseMenuComponent } from './warehouse-menu/warehouse-menu.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';

const routes: Routes = [
  {path: '',redirectTo:'login-page',pathMatch:'full'},
  {path: 'createOrder',component:AddItemComponent},
  {path: 'login-page',component:LoginPageComponent},
  {path: 'place-order',component:PlaceOrderComponent},
  {path: 'storeMenu',component:StoreMenuComponent},
  {path: 'orders',component:OrdersComponent},
  {path: 'employee',component:EmployeeComponent},
  {path: 'report' ,component:ReportComponent},
  {path: 'inventory',component:InventoryComponent},
  {path: 'warehouseMenu',component:WarehouseMenuComponent},
  {path: 'welcome',component:WelcomePageComponent},
  {path: 'check-report',component:CheckReportComponent},
  {path:'privacy',component:PrivacyComponent},
   {path:'deliveryMenu',component:DeliveryMenuComponent},
   {path:'editInventory',component:EditInventoryComponent},
   {path:'supplier',component:SupplierComponent},
   {path:'regionalMenu',component:RegionalMenuComponent}
   


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
