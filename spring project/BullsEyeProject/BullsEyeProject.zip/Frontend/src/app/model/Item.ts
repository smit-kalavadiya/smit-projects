export class Item {
    public id?: number;
    public name?:string;
    public quantity?: number;
    public price?: number;
    public season?: string;
    public description?: string;
    public weight?: number;
    public dimension?: string;
    // public tax?:number;
    public orderid?:number;
    // public grandtotal?:number;
    // public shipping?:number;
    // public subtotal?:number;

        
}
