export class Warehouse {
    public id?: number;
    public location?: string;
    public region?: string;  
}
