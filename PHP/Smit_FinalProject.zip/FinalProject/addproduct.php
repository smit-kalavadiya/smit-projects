<!DOCTYPE html>
<html lang="en">

<head>
  <?php
  include("include/connection.php");
  include("operation.php");
  ?>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body style="width:80%; margin-left:auto; margin-right:auto">
  <h1>Add Product</h1>
  <div>
    <form action="#" method="POST" enctype="multipart/form-data">

      <label for="pname">Product Name</label>
      <input type="text" id="pname" name="pname" placeholder="Product name">
      <label for="price">Price</label>
      <input type="text" id="price" name="price" placeholder="Price">
      <label for="description">Description</label>
      <input type="text" id="description" name="description" placeholder="Description">
      Product Image:
      <input type="file" accept="images/*" name="uploadedFile" id="fileToUpload">
      <input type="submit" name="login" value="Add Product" />

    </form>
  </div>
</body>

</html>

<?php
if (isset($_POST['login'])) {
  if (!isset($_FILES['uploadedFile']) || $_FILES['uploadedFile']['error'] == UPLOAD_ERR_NO_FILE) {
    echo "Please fill all the form data";
  } else {
    $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
    $fileName = $_FILES['uploadedFile']['name'];
    $fileSize = $_FILES['uploadedFile']['size'];
    $fileType = $_FILES['uploadedFile']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));

    $uploadFileDir = './uploads/';
    $dest_path = $uploadFileDir . $fileName;

    $sql = "INSERT INTO products(name, image, price, description,user_id) VALUES (?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $id = "2";
    $stmt->bind_param("ssdsi", $_POST['pname'], $fileName, $_POST['price'], $_POST['description'], $id);

    // filter for image upload
    if ($fileType != "image/jpeg" && $fileType != "image/png" && $fileType != "image/jpeg") {

      echo "Sorry, only JPG, PNG, and JPEG files are allowed.";
    } else {
      if ($fileSize > 2048000) {

        echo "Sorry, Image is larger than 2 MB";
      } else {
        if (file_exists($dest_path)) {
          echo "Sorry, file already exists.";
        } else {
          $stmt->execute();
          move_uploaded_file($fileTmpPath, $dest_path);
          echo "Data inserted";
        }
      }
    }
  }
}
?>