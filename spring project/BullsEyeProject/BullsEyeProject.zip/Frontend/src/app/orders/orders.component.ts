import { Component, ComponentRef, OnInit } from '@angular/core';
import { Item } from '../model/Item';
import { Order } from '../model/Order';
import { ItemService } from '../service/item.service';
import { OrderService } from '../service/order.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  dispatchOrder: Order = new Order();
  deliverOrder:Order = new Order();
  order: Order[] = [];
  ordersItem: Item[] = [];
  dispatchReadyOrder: Order[] = [];
  items: any = "";
  role: string = "";
  // orderId: number | undefined;
  storeOrders: Order[] = [];
  warehouseOrders: Order[] = [];

  constructor(private service: OrderService, private itemservice: ItemService, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.queryParams.subscribe((params => {
      this.role = params['role'];
      //  this.orderId = params['']
      console.log(this.role);
      this.service.getOrders().subscribe(data => {
        this.order = data;
        console.log(this.order);
        this.getOrderForStore();
        this.getOrderForWarehouse();
        this.getOrderForDispatch();
        console.log(this.storeOrders);
        console.log(this.warehouseOrders);
      })
    }))
    console.log(this.order);
  }
  ngOnInit(): void {
  }

  getItems(orderid: any) {
    var count = 1;
    this.itemservice.getItems(orderid).subscribe(data => {
      this.items = "";
      // this.items += "<table>";
      this.items += "<th>Number</th><th>Title</th><th>Quantity</th><th>Price</th> ";
      data.forEach(element => {
        this.ordersItem.push(element);
        this.items += "<tr>" + "<td>" + count + "</td>" + "<td>" + element.name + "<td>" + element.quantity + "</td>" + "<td>" + element.price + "</tr>"
        ++count;
      });
      // this.items += "</table>";
      // this.items += "Subtotal:"+this.i+"<br>Shipping"+this.items.shipping+"<br>Tax:"+this.items.tax+"<br>Total:"+this.items.grandtotal;
      Swal.fire({
        title: 'Items for Order #' + orderid,
        heightAuto: true,
        width: "30%",
        text:"center",
        background: "#fff",
        html: "<table>"+this.items+"</table>",
        confirmButtonText: 'OK',
      })
    });
    console.log(this.ordersItem);
  }

  dispatchOrders(orderId: any) {
    this.order.forEach(e => {
      if (e.id == orderId) {
        this.dispatchOrder = e;
      }
    })
    Swal.fire({

      title: 'Send Order #' + orderId + ' for Packaging?',
      heightAuto: true,
      showDenyButton: true,
      width: "25%",
      background: "#fff",
      html: "This Order will be sent for packaging and forwarded to the delivery person",
      confirmButtonText: 'Yes',
      denyButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.dispatchOrder.status = "Dispatching";
        console.log(this.dispatchOrder);
        Swal.fire('Saved!', '', 'success');
        this.service.dispatchOrder(this.dispatchOrder).subscribe(data => {

        })
      } else if (result.isDenied) {
        Swal.fire('Changes are not saved', '', 'info')
      }
    })
  }
  deliverOrders(orderId: any) {
    this.order.forEach(e => {
      if (e.id == orderId) {
        this.deliverOrder = e;
      }
    })
    Swal.fire({

      title: 'Deliver Order #' + orderId + ' to '+this.deliverOrder.address+" ?",
      heightAuto: true,
      showDenyButton: true,
      width: "25%",
      background: "#fff",
      html: "This Order will be marked as delivered",
      confirmButtonText: 'Yes',
      denyButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.deliverOrder.status = "Delivered";
        console.log(this.deliverOrder);
        Swal.fire('Saved!', '', 'success');
        this.service.dispatchOrder(this.deliverOrder).subscribe(data => {

        })
      } else if (result.isDenied) {
        Swal.fire('Changes are not saved', '', 'info')
      }
    })
  }
  getOrderForStore() {
    this.order.forEach(o => {
      if (o.orderby == "Store Manager") {
        this.storeOrders.push(o);
      }
    });
  }
  getOrderForDispatch() {
    this.order.forEach(o => {
      if (o.status == "Dispatching") {
        this.dispatchReadyOrder.push(o);
      }
    });
  }
  getOrderForWarehouse() {
    this.order.forEach(o => {
      if (o.orderby == "Warehouse Foreman") {
        this.warehouseOrders.push(o);
      }
    })
  }

}
