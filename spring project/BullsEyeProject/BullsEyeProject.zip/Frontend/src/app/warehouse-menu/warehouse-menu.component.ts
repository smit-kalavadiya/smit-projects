import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Order } from '../model/Order';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-warehouse-menu',
  templateUrl: './warehouse-menu.component.html',
  styleUrls: ['./warehouse-menu.component.css']
})
export class WarehouseMenuComponent implements OnInit {
  emp: Employee = new Employee();
  err:string = "";
  order: Order = new Order();

  orders: Order[] = [];
  constructor(private router: Router,private orderservice: OrderService) { }
  ngOnInit(): void {
    this.getOrders();
    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;

    if (Object.keys(this.emp).length == 0) {
      this.router.navigate(['/login-page']);
    }
  }
  getOrders(){
    this.orderservice.getOrders().subscribe(data=>{
    data.forEach(e=>{
      if(e.orderby == "Store Manager"){
        this.orders.push(e);
      }
    })
    })
  }
  onClickSubmit(data: any) {

    this.order.type = data.type;
    this.order.orderby = this.emp.role;
    if(this.order.date == null){
      this.order.date = new Date();
    }else{
      this.order.date = data.date;
    }
    this.order.status = "In progress";
    this.order.address = data.address;
    this.order.title = data.title;

    if(this.order.type != null && this.order.type != "" && this.order.date != null && this.order.address != null && this.order.address != ""){
      this.orderservice.addOrder(this.order).subscribe((data: Order) => {  
        sessionStorage.setItem('orderId', JSON.stringify(data));    
        this.router.navigate(['/createOrder']);
      });
    }else{
      this.err = "Please enter all the fields";
    }
    
      console.log(this.order);
  }
  logout() {
    sessionStorage.clear();
    this.router.navigate(['/login-page']);
  }
}
