import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Products } from '../model/Products';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http: HttpClient) { }


  getProducts(){
    return this.http.get<Products[]>("http://localhost:8080/products");
  }

  getProduct(id:number){
    return this.http.post<Products>("http://localhost:8080/products",id);
  }


  updateProduct(product:Products){
    return this.http.post<Products>("http://localhost:8080/updateproduct",product);

  }
  addProduct(product:Products){
    return this.http.post<Products>("http://localhost:8080/addproduct",product);
  }
  deleteProduct(id:number){
    return this.http.post<Products>("http://localhost:8080/deleteproduct",id);
  }


  
}
