import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Store } from '../model/Store';


@Injectable({
  providedIn: 'root'
})
export class StoreService {
  

  constructor(private http: HttpClient) { 

  }

  addNewStore(store: Store): Observable<Store>{
    return this.http.post<Store>("http://localhost:8080/stores",store);
  }


  getStore(): Observable<Store[]>{
    return this.http.get<Store[]>("http://localhost:8080/stores");
  }

 

}
