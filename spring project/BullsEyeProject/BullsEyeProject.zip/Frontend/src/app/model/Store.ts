export class Store {
    public id?: number;
    public location?: string;
    public region?: string;
         
}
