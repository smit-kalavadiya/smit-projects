<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include("include/connection.php");
    include("operation.php");

    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <h1>Welcome, Admin</h1>
    <a href="clientpage.php"><button class="card-button-add">Visit Client side</button></a> </br></br>
    <a href="addproduct.php"><button class="card-button-add">Add Product</button></a>
    <h1 style="text-align:center">List of Products</h1>
    <form action="#" method="post">
        <?php
        $result = prepare::getAll($conn); // oop function call
        while ($row = $result->fetch_assoc()) {
        ?>
            <div class="card">
                <h2><?php echo $row['name']; ?></h2>
                Description: <?php echo $row['description'];  ?>
                <p class="price">
                    <img src=<?php echo "uploads/" . $row['image']; ?> class="image" />
                    CA: $<?php $id = $row['product_id'];
                        echo $row['price']; ?>
                </p>
                <button class="card-button-delete" name="delete" value=<?php echo $row['product_id']; ?> type="submit">Delete</button>
                <a href="editproduct.php?pid=<?php echo $row['product_id']; ?> "> <button class="card-button-edit" type="button" value=<?php echo $row['product_id']; ?>>Edit</button></a>
            </div>
        <?php } ?>
    </form>
</body>

</html>

<?php
if (isset($_POST['delete'])) {
    prepare::delete($conn, $_POST['delete']);
    header("Refresh:0");
}

?>