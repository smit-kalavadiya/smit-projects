import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Order } from '../model/Order';
import { EmployeeService } from '../service/employee.service';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-delivery-menu',
  templateUrl: './delivery-menu.component.html',
  styleUrls: ['./delivery-menu.component.css']
})
export class DeliveryMenuComponent implements OnInit {
  emp: Employee = new Employee();
  orders:Order[] = [];
  constructor(private service: OrderService, private router: Router) { }

  ngOnInit(): void {
    this.service.getOrders().subscribe(data=>{
      data.forEach(e => {
        if(e.orderby == "Store Manager" && e.status == "Dispatching"){
          this.orders.push(e);
        }
      });
    })
    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;

    if (Object.keys(this.emp).length == 0) {
      this.router.navigate(['/login-page']);
    }
  }
  logout() {
    sessionStorage.clear();
    this.router.navigate(['/login-page']);
  }

}
