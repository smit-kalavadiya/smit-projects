import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  emp:Employee[] = [];
  constructor(private service: EmployeeService) { }

  ngOnInit(): void {
    this.getData();
  }

  getData(){
    this.service.getEmployees().subscribe(data=>{
      this.emp = data;
      console.log(this.emp);
    })
  }
  
}
