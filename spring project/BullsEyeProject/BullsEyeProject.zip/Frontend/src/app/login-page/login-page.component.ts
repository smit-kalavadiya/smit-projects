import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  constructor(private service: EmployeeService, private router: Router) { }

  emp: Employee = new Employee();
  message: string = "";

  ngOnInit(): void {
    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;
   
    if (Object.keys(this.emp).length != 0) {
      if (this.emp.role == "Store Manager") {
        this.router.navigate(['/storeMenu']);
      }  if (this.emp.role == "Warehouse Foreman") {
        this.router.navigate(['/warehouseMenu']);
      }  if (this.emp.role == "Delivery Driver") {
        this.router.navigate(['/deliveryMenu']);
      } if (this.emp.role == "Regional Manager") {
        this.router.navigate(['/regionalMenu']);
      }
    }
    else {
      this.router.navigate(['/login-page']);
    }

  }

  onClickSubmit(email: any) {
    this.emp.email = email.uname;
    this.emp.password = email.pass;
    this.service.getEmployeeByEmail(this.emp).subscribe((data: Employee) => {

      if (data == null) {
        this.message = "Incorrect credentials";
        return;
      }
      if (data.email == this.emp.email && data.password == this.emp.password) {
        sessionStorage.setItem('userDetails', JSON.stringify(data));
        if (data.role == "Store Manager") {
          this.router.navigate(['/storeMenu']);
        }
        if (data.role == "Warehouse Foreman") {
          this.router.navigate(['/warehouseMenu']);
        }
        if (data.role == "Delivery Driver") {
          this.router.navigate(['/deliveryMenu']);
        }
        if (data.role == "Regional Manager") {
          this.router.navigate(['/regionalMenu']);
        }
      }
      else {
        this.message = "Incorrect credentials";
      }
    });
  }
  

}
