import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Report } from '../model/Report';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-check-report',
  templateUrl: './check-report.component.html',
  styleUrls: ['./check-report.component.css']
})
export class CheckReportComponent implements OnInit {

  emp: Employee = new Employee();
  reports: Report[] = []; 
  constructor(private service: ReportService, private router: Router) { }

  ngOnInit(): void {


    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;
    this.getReport();
    
    if (Object.keys(this.emp).length == 0) {
      this.router.navigate(['/login-page']);
    }

  }

  getReport(){
    this.service.getReport(this.emp.role as string).subscribe(data=>{
      this.reports = data;
      console.log(this.reports);
    })
  }

  

}
