import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegionalMenuComponent } from './regional-menu.component';

describe('RegionalMenuComponent', () => {
  let component: RegionalMenuComponent;
  let fixture: ComponentFixture<RegionalMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegionalMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegionalMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
