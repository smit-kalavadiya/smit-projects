import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { StoreMenuComponent } from './store-menu/store-menu.component';
import { WarehouseMenuComponent } from './warehouse-menu/warehouse-menu.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { AddItemComponent } from './add-item/add-item.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { InventoryComponent } from './inventory/inventory.component';
import { ReportComponent } from './report/report.component';
import { EmployeeService } from './service/employee.service';
import { CheckReportComponent } from './check-report/check-report.component';
import { EmployeeComponent } from './employee/employee.component';
import { OrdersComponent } from './orders/orders.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { DeliveryMenuComponent } from './delivery-menu/delivery-menu.component';
import { EditInventoryComponent } from './edit-inventory/edit-inventory.component';
import { SupplierComponent } from './supplier/supplier.component';
import { RegionalMenuComponent } from './regional-menu/regional-menu.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    WelcomePageComponent,
    StoreMenuComponent,
    WarehouseMenuComponent,
    PlaceOrderComponent,
    AddItemComponent,
    InventoryComponent,
    ReportComponent,
    CheckReportComponent,
    EmployeeComponent,
    OrdersComponent,
    PrivacyComponent,
    DeliveryMenuComponent,
    EditInventoryComponent,
    SupplierComponent,
    RegionalMenuComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [EmployeeService], //missing provider
  bootstrap: [AppComponent]
})
export class AppModule { }
