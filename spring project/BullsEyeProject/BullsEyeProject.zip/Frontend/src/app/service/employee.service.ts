import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../model/Employee';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  

  constructor(private http: HttpClient) { 

  }
 
  getEmployees() {
    return this.http.get<Employee[]>("http://localhost:8080/Employee");
  }

  getEmployeeByEmail(emp_email: Employee): Observable<Employee>{
    return this.http.post<Employee>("http://localhost:8080/GetEmployee",emp_email);
  } 

}
