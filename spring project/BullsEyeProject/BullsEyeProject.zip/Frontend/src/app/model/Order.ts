export class Order {
    public id?: number;
    public type?: string;
    public date?: Date;
    public address?: string;
    public status?: string;
    public title?: string;
    public orderby?: string;
    public subtotal?: number;
    public grandtotal?: number;
    public tax?: number;
    public shipping?: number;


}
