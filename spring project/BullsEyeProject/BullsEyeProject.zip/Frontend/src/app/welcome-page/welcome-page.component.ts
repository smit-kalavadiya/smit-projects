import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Order } from '../model/Order';
import { EmployeeService } from '../service/employee.service';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.css']
})
export class WelcomePageComponent implements OnInit {
 
  constructor(){}
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  
}