<?php 

$hostname = "localhost:3308";
$username = "smit";
$password = "smit123";
$dbname = "finalproject";

$conn = new mysqli($hostname, $username, $password, $dbname);

if($conn->connect_error){
    die("Error in connection " . $conn->connect_error);
}

?>