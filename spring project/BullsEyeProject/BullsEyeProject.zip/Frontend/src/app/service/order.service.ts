import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, ObservableLike } from 'rxjs';
import { Order } from '../model/Order';

//This is service file of add-item
@Injectable({
  providedIn: 'root'
})
export class OrderService {
  

  constructor(private http: HttpClient) { 

  }

  addOrder(order: Order): Observable<Order>{
    console.log(order.title);
    return this.http.post<Order>("http://localhost:8080/sendOrder",order);
  }

  getOrders() {
    return this.http.get<Order[]>("http://localhost:8080/Orders");
  }

  dispatchOrder(order:Order):Observable<Order>{
    return this.http.post<Order>("http://localhost:8080/updateorder",order);
  }
}
