
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Report } from '../model/Report';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  myDate?: Date;

  constructor(private service: ReportService, private router: Router) {

    this.myDate = new Date();

  }

  emp: Employee = new Employee();
  report: Report = new Report();
  isSubmitted: boolean = false;

  ngOnInit(): void {
    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;

    if (Object.keys(this.report).length != 0) {
      this.router.navigate(['/report']);
    }
    else {
      this.router.navigate(['/report']);
    }

  }

  onClickSubmit(data: any) {

    this.report.name = data.name;
    this.report.email = data.email;
    this.report.phone = data.phone;
    this.report.submittedTo = data.managers;
    this.report.date = data.dateOfReport;
    this.report.message = data.message;


    this.service.sendReport(this.report).subscribe((data: Report) => {

      this.router.navigate(['/']);
    });
  }

}