export class Employee {

    public id?: number;
    public address?: string;
    public email?: string;
    public username?: string;
    public name?: string;
    public role?: string;
    public salary?: number;
    public phone?: number;
    public password?: string;    
    public profileUrl?: string;
}
