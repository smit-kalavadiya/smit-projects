export class Products {
    
    public id?: number;
    public cost?: number;
    public description?: string;
    public image?: string;
    public name?: string;
    public quantity?: number;
    public season?: string;
    public shelflocation?: number;
    public weight?: number;
}