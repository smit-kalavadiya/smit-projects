<?php

include("include/connection.php");
class prepare
{

    /**
     * this function will return all the products
     * @param $conn is a connection with database
     * 
     */
    public static function getAll($conn)
    {
        $sql = "select * from products";
        $result = $conn->query($sql);
        return $result;
    }

    /**
     * this function will return all the products
     * @param $conn is a connection with database
     * @param $id is perticular id of the product
     */
    public static function delete($conn, $id)
    {
        $sql = "delete from products where product_id= ? ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    /**
     * this function will return all the products
     * @param $conn is a connection with database
     * @param $id is perticular id of the product
     */
    public static function getProductById($conn, $id)
    {
        $sql = "select * from products where product_id= ? ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();
        return $product;
    }
    /**
     * this function will return all the products
     * @param are data for the product
     */
    public static function updateProductById($conn, $id, $name, $image, $price, $description)
    {
        $sql = "UPDATE products SET name=?, image=?, price=?,description=? WHERE product_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdsi", $name, $image, $price, $description, $id);
        if ($stmt->execute()) {
            return true;
        }
    }
}
