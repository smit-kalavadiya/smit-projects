<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include("include/connection.php");
    $emailErr = "";
    $paswordErr = "";

    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome To E-Commerce</title>
    <link rel="stylesheet" href="css/style.css">
    <?php
    if (isset($_POST['login'])) {
        if (empty($_POST['email'])) {
            $emailErr = "Please Enter Email";
        }
        if (empty($_POST['password'])) {
            $paswordErr = "Please Enter Password";
        }

        $email = $_POST['email'];
        $pass = $_POST['password'];
        $sql = "select * from users where email = '" . $email . "' ";

        if ($result = $conn->query($sql)) {
            while ($row = mysqli_fetch_row($result)) {
                if ($row[1] == $email && $row[2] == md5($pass)) {

                    // Check user is admin or client
                    if ($row[3] == "Admin") {
                        header('Location: adminpage.php');
                    } else {
                        header('Location: clientpage.php');
                    }
                }
            }
        }
    }
    ?>
</head>

<body style="margin-top:10%;width:30%; margin-left:auto; margin-right:auto">
    <form action="#" method="POST">

        Email: <input type="text" name="email" placeholder="Enter Email" /><span style="color:red">* <?php echo $emailErr ?> </span><br>
        password: <input type="password" name="password" placeholder="Enter password" /> <span style="color:red">* <?php echo $paswordErr ?> </span><br>
        <input type="submit" name="login" value="Login" />
    </form>
</body>

</html>