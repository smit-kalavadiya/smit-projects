import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { Order } from '../model/Order';
import { Products } from '../model/Products';
import { Report } from '../model/Report';
import { EmployeeService } from '../service/employee.service';
import { OrderService } from '../service/order.service';
import { ProductsService } from '../service/products.service';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-regional-menu',
  templateUrl: './regional-menu.component.html',
  styleUrls: ['./regional-menu.component.css']
})
export class RegionalMenuComponent implements OnInit {
  err:string = "";
  warehouseorders: Order[]=[];
  storeOrders:Order[] =[];
  employees: Employee[]=[];
  emp: Employee = new Employee();
  reports:Report[]=[];
  order: Order = new Order();
  products:Products[] = [];

  constructor(private service: EmployeeService,private orderservice: OrderService, private router: Router,private reportSer:ReportService,private proSer:ProductsService) { }

  ngOnInit(): void {
    this.emp = JSON.parse(sessionStorage.getItem("userDetails") || '{}') as Employee;

    this.orderservice.getOrders().subscribe(data=>{
      data.forEach(d => {
        if(d.orderby == "Store Manager"){
          this.storeOrders.push(d);
        }else{
          this.warehouseorders.push(d);
        }
      });

    this.reportSer.getReport("Regional Manager").subscribe(data=>{
      this.reports = data;
    })
    })
    if (Object.keys(this.emp).length == 0) {
      this.router.navigate(['/login-page']);
    }
    this.service.getEmployees().subscribe(data=>{
      this.employees = data;
    })
    this.proSer.getProducts().subscribe(data=>{
      this.products = data;
    })
  }
  
  logout() {
    sessionStorage.clear();
    this.router.navigate(['/login-page']);
  }

}