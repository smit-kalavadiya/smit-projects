import { Injectable } from '@angular/core';
import { Report } from '../model/Report';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportService {


  constructor(private http: HttpClient) {
  }

  sendReport(report: Report): Observable<Report> {
    return this.http.post<Report>("http://localhost:8080/Report", report);
  }

  getReport(role: string) {
    console.log(role);
    return this.http.get<Report[]>("http://localhost:8080/getReportBySubmitted/" + role);
  }
}