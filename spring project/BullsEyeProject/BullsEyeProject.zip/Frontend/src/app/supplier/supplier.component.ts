import { Component, OnInit } from '@angular/core';
import { Supplier } from '../model/Supplier';
import { SupplierService } from '../service/supplier.service';
@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent implements OnInit {
  sup:Supplier[] = [];

  constructor(private service: SupplierService) { }

  ngOnInit(): void {
    this.getData();

  }
  getData(){
    this.service.getSuppliers().subscribe(data=>{
      this.sup = data;
      console.log(this.sup);
    })
  }

}
