import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Products } from '../model/Products';
import { ProductsService } from '../service/products.service';

@Component({
  selector: 'app-edit-inventory',
  templateUrl: './edit-inventory.component.html',
  styleUrls: ['./edit-inventory.component.css']
})
export class EditInventoryComponent implements OnInit {
  product: Products = new Products();
  new:string = "";
  constructor(private service: ProductsService,private router:Router,private activatedRoute: ActivatedRoute) { 
    this.activatedRoute.queryParams.subscribe((params => {
      this.new = params['new'];

      if(this.new != "new"){
        this.productId = JSON.parse(sessionStorage.getItem("productId") || '{}') as number;
      this.service.getProduct(this.productId).subscribe(data=>{
        this.product = data;
      })
      }
      
      console.log(this.new);
  }))
}
  productId: number = 0;

  ngOnInit(): void {

  }

  onClickSubmit(data: any) {
    this.product.name=data.name;
    this.product.description=data.description;
    this.product.cost=data.cost;
    this.product.quantity=data.quantity;
    this.product.weight=data.weight;
    this.product.season=data.season;
    this.product.shelflocation=data.shelflocation; 
    this.product.image=data.image;

    console.log(data);

    this.service.updateProduct(this.product).subscribe((data: Products) => {
      console.log("Product updated.");
      this.router.navigate(['/inventory']);
    })
    // this.clearFields();

    if(this.new == "true"){
      this.service.addProduct(this.product).subscribe((data:Products) =>{
        console.log("Product Added");
        this.router.navigate(['/inventory']);
      })
    }
  }

  clearFields(){
        this.product.name="";
        this.product.description="";
        this.product.cost=0;
        this.product.quantity=0;
        this.product.weight=0;
        this.product.season="";
        this.product.shelflocation=0; 
  }

}
